# GPL Time Auto Updater

Get a automatically update from gpltimes.com

* get auto update for single purchase
* get auto update for the subscription